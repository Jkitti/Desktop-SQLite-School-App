﻿using System;
using Microsoft.Data.Sqlite;
using System.Collections.Generic;

namespace DataAccessLibrary
{
    public static class DataAccess
    {
        public static SqliteConnection LocalConnection = new SqliteConnection("Filename=sqliteCapstone.db");

        public static void InitializeDatabase()
        {
            using (LocalConnection)
            {
                LocalConnection.Open();
                String personTableCommand = "DROP TABLE IF EXISTS Person; CREATE TABLE " +
                                             "Person (pid int(11) NOT NULL, fname varchar(45) NOT NULL, " +
                                             "lname varchar(45) NOT NULL)";

                String teacherTableCommand = "DROP TABLE IF EXISTS Teacher; CREATE TABLE " +
                                             "Teacher (tid int(11) NOT NULL, office_location varchar(45) NOT NULL, " +
                                             "office_hours varchar(45) NOT NULL,phone char(10) NOT NULL)";

                String courseTableCommand = "DROP TABLE IF EXISTS Course; " +
                                      "CREATE TABLE Course (`cid` int(11) PRIMARY KEY, name varchar(60) NOT NULL, " +
                                            "crn int(11) NOT NULL, section_number int(3) NOT NULL, credit_hours int(1) NOT NULL," +
                                            "remaining_seats varchar(2) NOT NULL, max_seats int(2) NOT NULL, " +
                                            "meeting_times varchar(60) NOT NULL, location varchar(60) NOT NULL, teacher int(11) NOT NULL)";

                String credentialsTableCommand = "DROP TABLE IF EXISTS Credentials; CREATE TABLE " +
                                                 "Credentials (cid int(11) NOT NULL, password varchar(45) NOT NULL) ";

                String gradeitemTableCommand = "DROP TABLE IF EXISTS Course_grade_item; CREATE TABLE " +
                                               "Course_grade_item (aid INTEGER PRIMARY KEY, cid int(11) NOT NULL," +
                                               "name varchar(60) NOT NULL, description varchar(600) NOT NULL, " +
                                               "grade_type varchar(60) NOT NULL, max_grade int(11) NOT NULL," +
                                               "FOREIGN KEY (cid) REFERENCES Course(cid), " +
                                               "FOREIGN KEY (grade_type) REFERENCES Course_rubric(assignment_type))";

                String studentTableCommand = "DROP TABLE IF EXISTS Student; CREATE TABLE " +
                                             "Student (sid int(11) NOT NULL,  email varchar(60) NOT NULL," +
                                             "phone char(10) NOT NULL,  degree_program varchar(4) NOT NULL," +
                                             "degree_progress varchar(60) NOT NULL, gpa varchar(4) NOT NULL)";

                String participantTableCommand = "DROP TABLE IF EXISTS Course_student_participant; CREATE TABLE " +
                                                 "Course_student_participant (cid int(11) NOT NULL, sid int(11) NOT NULL)";

                String participantGradeTableCommand = "DROP TABLE IF EXISTS Course_student_participant_grade; CREATE TABLE " +
                                                 "Course_student_participant_grade (cid int(11) NOT NULL, sid int(11) NOT NULL, grade double NOT NULL)";

                String studentGradeItemGradeTableCommand = "DROP TABLE IF EXISTS Course_student_grade_item_grade; CREATE TABLE " +
                                                           "Course_student_grade_item_grade (aid int(11) NOT NULL, sid int(11) NOT NULL," +
                                                           "grade int(4) DEFAULT NULL, graded int (1) NOT NULL, FOREIGN KEY (aid) REFERENCES Course_grade_item(aid))";

                String courseRubricCommand = "DROP TABLE IF EXISTS Course_rubric;  CREATE TABLE " +
                                             "Course_rubric (rid INTEGER PRIMARY KEY, cid int(11) NOT NULL, assignment_type varchar(60) NOT NULL," +
                                             " grade_percentage double NOT NULL, FOREIGN KEY (cid) REFERENCES Course(cid))";

                String courseLectureCommand = "DROP TABLE IF EXISTS Course_lecture;  CREATE TABLE " +
                                             "Course_lecture (cid INTEGER NOT NULL, text TEXT NOT NULL, File BLOB," +
                                             " FOREIGN KEY (cid) REFERENCES Course(cid))";


                SqliteCommand createPersonTable = new SqliteCommand(personTableCommand, LocalConnection);
                SqliteCommand createTeacherTable = new SqliteCommand(teacherTableCommand, LocalConnection);
                SqliteCommand createCourseTable = new SqliteCommand(courseTableCommand, LocalConnection);
                SqliteCommand createCredentialsTable = new SqliteCommand(credentialsTableCommand, LocalConnection);
                SqliteCommand createGradeItemTable = new SqliteCommand(gradeitemTableCommand, LocalConnection);
                SqliteCommand createStudentTable = new SqliteCommand(studentTableCommand, LocalConnection);
                SqliteCommand createParticipantTable = new SqliteCommand(participantTableCommand, LocalConnection);
                SqliteCommand createGradeTable = new SqliteCommand(participantGradeTableCommand, LocalConnection);
                SqliteCommand createStudentGradeItemTable = new SqliteCommand(studentGradeItemGradeTableCommand, LocalConnection);
                SqliteCommand createRubricTable = new SqliteCommand(courseRubricCommand, LocalConnection);
                SqliteCommand createLectureTable = new SqliteCommand(courseLectureCommand, LocalConnection);

                createPersonTable.ExecuteReader();
                createTeacherTable.ExecuteReader();
                createCourseTable.ExecuteReader();
                createCredentialsTable.ExecuteReader();
                createStudentTable.ExecuteReader();
                createParticipantTable.ExecuteReader();
                createRubricTable.ExecuteReader();
                createGradeItemTable.ExecuteReader();
                createStudentGradeItemTable.ExecuteReader();
                createGradeTable.ExecuteReader();
                createLectureTable.ExecuteReader();
            }
        }
        public static void AddData(string inputText)
        {
            using (LocalConnection)
            {
                LocalConnection.Open();

                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.Connection = LocalConnection;
                insertCommand.CommandText = inputText;

                insertCommand.ExecuteReader();

                LocalConnection.Close();
            }

        }
    }
}
