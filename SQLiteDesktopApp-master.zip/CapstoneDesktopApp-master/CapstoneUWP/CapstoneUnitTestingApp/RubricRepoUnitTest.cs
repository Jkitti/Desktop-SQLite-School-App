﻿using CapstoneUWP.DAL.Repositories;
using DataAccessLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CapstoneUnitTestingApp
{
    [TestClass]
    public class RubricRepoUnitTests
    {
        string course = "INSERT INTO Course (cid, name, crn, section_number, credit_hours, remaining_seats, max_seats, meeting_times, location, teacher)" +
                        "VALUES (" + 1 + ",'" + "CS1" + "'," + 32050 + "," + 1 + "," + 3 +
                        "," + 30 + "," + 30 + ",'" + "M&W 3:00-4:00" + "','" + "Tlc3101" + "'," + 3101 + ")";
        string rubric = "INSERT INTO Course_rubric (rid, cid, assignment_type, grade_percentage) VALUES " +
                        "(" + 0 + "," + 1301 + ",'" + "Quiz" + "'," + 0.5 + ")";


        [TestMethod]
        public void AddRubricTest()
        {
            {
                ChangelogModifier.CreateChangeLog();
                DataAccess.InitializeDatabase();
                DataAccess.AddData(this.course);
                DataAccess.AddData(this.rubric);
                var rubricRepo = new RubricRepository();
                rubricRepo.AddRubricItem(1301, "Exam", 0.5);
                var rubrics = rubricRepo.GetAllRubricItems(1301);
                Assert.AreEqual(2, rubrics.Count);
                ChangelogModifier.DeleteChangelog();
            }
        }

        [TestMethod]
        public void EditRubricTest()
        {
            {
                ChangelogModifier.CreateChangeLog();
                var rubricRepo = new RubricRepository();
                rubricRepo.EditRubricItem(0, "Homework", 0.5);
                var rubrics = rubricRepo.GetAllRubricItems(1301);
                Assert.AreEqual("Homework", rubrics[0].AssignmentType);
                ChangelogModifier.DeleteChangelog();
            }
        }


        [TestMethod]
        public void GetRubricTypesTest()
        {
            {
                ChangelogModifier.CreateChangeLog();
                var rubricRepo = new RubricRepository();
                var rubrics = rubricRepo.GetAllRubricItems(1301);
                var types = rubricRepo.GetTypes(rubrics);
                Assert.AreEqual("Homework", types[0]);
                Assert.AreEqual("Exam", types[1]);
                ChangelogModifier.DeleteChangelog();
            }
        }

        [TestMethod]
        public void GetPercentageTotalTest()
        {
            {
                var rubricRepo = new RubricRepository();
                var total = rubricRepo.GetRubricPercentageTotal(1301);
                Assert.AreEqual(1.0, total);
            }
        }
    }
}

