﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Display_Model;
using CapstoneUWP.Model.Repo_Model;
using CapstoneUWP.View.GradeItemPages;
using CapstoneUWP.View.RubricPages;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CourseHomePage : Page
    {
        private ViewParameters pageParameters;
        private GradeItemController controller;

        public CourseHomePage()
        {
            this.InitializeComponent();
            this.controller = new GradeItemController();
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters) e.Parameter;
            this.usernameTextBox.Text = this.pageParameters.Username;
            this.NavView.Content = this.pageParameters.CourseName;
            var repo = new GradeItemRepository();
            this.gradeItemList.ItemsSource = repo.GetGradeDisplayItems(this.pageParameters.CourseId);
            this.NavView.IsBackEnabled = true;
        }

        /// <summary>
        /// Handles the Click event of the gradedButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void gradedButton_Click(object sender, RoutedEventArgs e)
        {
            var displaygradeItem = (GradeItemGradeDisplay)this.gradeItemList.SelectedItem;
            if (displaygradeItem != null)
            {
                var gradeItem = displaygradeItem.GradeItem;
                this.pageParameters.GradeItem = gradeItem;
                Frame.Navigate(typeof(StudentGradesPage), this.pageParameters);
            }

        }

        /// <summary>
        /// Handles the Click event of the ungradedButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void ungradedButton_Click(object sender, RoutedEventArgs e)
        {
            var gradeItem = (GradeItemGradeDisplay)this.gradeItemList.SelectedItem;
            if (gradeItem != null || gradeItem.UngradedItems.Count == 0)
            {
                var queue = new Queue<GradeItemGrade>(gradeItem.UngradedItems);
                this.pageParameters.Grades = queue;
                if (gradeItem.UngradedCount != 0)
                {
                    Frame.Navigate(typeof(EditStudentGradePage), this.pageParameters);
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the gradeSingleButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private async void gradeSingleButton_Click(object sender, RoutedEventArgs e)
        {
            if ((StudentGradeItemGrade) this.studentGradedItemList.SelectedItem != null && 
                (StudentGradeItemGrade)this.studentUngradedItemList.SelectedItem != null)
            {
                var invalidSelectionDialog = new ContentDialog
                {
                    Title = "Selection Error",
                    Content = "Please select only one item",
                    PrimaryButtonText = "Okay"
                };
                var unused = await invalidSelectionDialog.ShowAsync();
                return;
            }
            else if ((StudentGradeItemGrade) this.studentGradedItemList.SelectedItem != null)
            {
                var displaygradeItem = (StudentGradeItemGrade)this.studentGradedItemList.SelectedItem;
                var queue = new Queue<GradeItemGrade>();
                var gradeItem = new GradeItemGrade
                {
                    assignmentID = displaygradeItem.assignmentID,
                    studentID = displaygradeItem.studentID,
                    Grade = displaygradeItem.Grade,
                    Graded = false
                };
                queue.Enqueue(gradeItem);
                this.pageParameters.Grades = queue;
                Frame.Navigate(typeof(EditStudentGradePage), this.pageParameters);
            }
            else if ((StudentGradeItemGrade)this.studentUngradedItemList.SelectedItem != null)
            {
                var displaygradeItem = (StudentGradeItemGrade)this.studentUngradedItemList.SelectedItem;
                var queue = new Queue<GradeItemGrade>();
                var gradeItem = new GradeItemGrade
                {
                    assignmentID = displaygradeItem.assignmentID,
                    studentID = displaygradeItem.studentID,
                    Grade = displaygradeItem.Grade,
                    Graded = false
                };
                queue.Enqueue(gradeItem);
                this.pageParameters.Grades = queue;
                Frame.Navigate(typeof(EditStudentGradePage), this.pageParameters);
            }
        }

        /// <summary>
        /// Handles the Tapped event of the RubricNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void RubricNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(RubricItemsPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the GradeItemNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void GradeItemNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(GradeItemPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the GradesNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void GradesNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(CourseGradesPage), this.pageParameters);
        }

        /// <summary>
        /// Navs the view back requested.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The <see cref="NavigationViewBackRequestedEventArgs"/> instance containing the event data.</param>
        private void NavView_BackRequested(NavigationView sender, NavigationViewBackRequestedEventArgs args)
        {
            Frame.Navigate(typeof(TeacherHomepage), this.pageParameters);
        }

        /// <summary>
        /// Handles the SelectionChanged event of the gradeItemList control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="SelectionChangedEventArgs"/> instance containing the event data.</param>
        private void gradeItemList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var gradeItem = (GradeItemGradeDisplay)this.gradeItemList.SelectedItem;
            var ungradedGrades =
                this.controller.CreateAllStudentGradeItemGrades(gradeItem.UngradedItems, this.pageParameters.CourseId);
            var gradedGrades =
                this.controller.CreateAllStudentGradeItemGrades(gradeItem.GradedItems, this.pageParameters.CourseId);
            this.studentUngradedItemList.ItemsSource = ungradedGrades;
            this.studentGradedItemList.ItemsSource = gradedGrades;
        }
    }
}
