﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Repo_Model;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TeacherHomepage : Page
    {
        private ViewParameters pageParameters;
        TeacherRepository repo = new TeacherRepository();
        public TeacherHomepage()
        {
            this.InitializeComponent();
            var courses = this.repo.GetAllCourses();
            this.coursesList.ItemsSource = courses;
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            var username = this.pageParameters.Username;
            this.usernameTextBox.Text = username;
        }

        /// <summary>
        /// Handles the Click event of the SelectButton_OnClickButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void SelectButton_OnClickButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var course = (Course)button.DataContext;
            var courseId = course.CourseId;
            var para = new ViewParameters{CourseId = courseId, CourseName = course.Name, Username = this.pageParameters.Username};
            Frame.Navigate(typeof(CourseHomePage),para);
        }
    }
}
