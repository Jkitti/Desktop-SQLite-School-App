﻿using System;
using CapstoneUWP.DAL.Repositories;

namespace CapstoneUWP.View
{
    public class InputValidator
    {
        /// <summary>
        /// Validates the name.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        private static string validateName(string name)
        {
            var errors = string.Empty;
            if (!(System.Text.RegularExpressions.Regex.IsMatch(name, "^[a-zA-Z]+$")))
            {
                errors = "-Name is invalid. Entry must have only letters and be less than 60 characters long" +
                         Environment.NewLine;
            }
            return errors;
        }

        /// <summary>
        /// Validates the identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        private static string validateId(string id)
        {
            var errors = string.Empty;
            if (id.Length > 11 || !int.TryParse(id, out _) || id.Length == 0)
            {
                errors = "-Id must be less than 12 digits long and only numbers" + Environment.NewLine;
            }
            return errors;
        }

        /// <summary>
        /// Validates the description.
        /// </summary>
        /// <param name="description">The description.</param>
        /// <returns></returns>
        private static string validateDescription(string description)
        {
            var errors = string.Empty;
            if (description.Length > 600)
            {
                errors = "-Description can only be 600 characters long" + Environment.NewLine;
            }
            else if (description.Length == 0)
            {
                errors = "-Description cannot be empty" + Environment.NewLine;
            }
            return errors;
        }

        /// <summary>
        /// Validates the grade.
        /// </summary>
        /// <param name="grade">The grade.</param>
        /// <returns></returns>
        private static string validateGrade(string grade)
        {
            var errors = string.Empty;
            if (grade.Length > 3 || !int.TryParse(grade, out _) || grade.Length == 0)
            {
                errors = "-Grade must be less than 3 digits long and only numbers" + Environment.NewLine;
            }
            return errors;
        }

        /// <summary>
        /// Validates the type.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        private static string validateType(string type, int id)
        {
            var rubricRepo = new RubricRepository();
            var rubricitems = rubricRepo.GetAllRubricItems(id);
            var types = rubricRepo.GetTypes(rubricitems);
            var errors = string.Empty;
            if (!types.Contains(type))
            {
                errors = "-Type must be a rubric type" + Environment.NewLine;
            }
            return errors;
        }

        /// <summary>
        /// Validates the type of the rubric.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public string ValidateRubricType(string type,int id)
        {
            var rubricRepo = new RubricRepository();
            var rubricitems = rubricRepo.GetAllRubricItems(id);
            var types = rubricRepo.GetTypes(rubricitems);
            var errors = string.Empty;
            if (types.Contains(type) || !System.Text.RegularExpressions.Regex.IsMatch(type, "^[a-zA-Z]+$"))
            {
                errors = "-Type must be a new rubric type and only contain letters" + Environment.NewLine;
            }
            return errors;
        }


        /// <summary>
        /// Validates the grade item entries.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="description">The description.</param>
        /// <param name="grade">The grade.</param>
        /// <param name="type">The type.</param>
        /// <param name="courseId">The course identifier.</param>
        /// <returns></returns>
        public string ValidateGradeItemEntries(string name, string description, string grade, string type, int courseId)
        {
            var errors =  validateName(name) +
                         validateDescription(description) + validateGrade(grade) + validateType(type,courseId);
            return errors;
        }



        /// <summary>
        /// Validates the grade item grade.
        /// </summary>
        /// <param name="assignmentId">The assignment identifier.</param>
        /// <param name="grade">The grade.</param>
        /// <returns></returns>
        public static bool ValidateGradeItemGrade(int assignmentId, int grade)
        {
            var repo = new GradeItemRepository();
            var gradeItem = repo.GetGradeItem(assignmentId);
            if (grade > gradeItem.MaxGrade || grade < 0)
            {
                return false;
            }
            return true;
        }
    }
}
