﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Repo_Model;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class EditGradeItemPage : Page
    {
        private ViewParameters pageParameters;
        private GradeItemController controller;
        public List<String> types;
        private int courseID;
        private readonly InputValidator validator;

        public EditGradeItemPage()
        {
            this.InitializeComponent();
            this.controller = new GradeItemController();
            this.validator = new InputValidator();
        }


        /// <summary>
        /// Handles the Click event of the EditButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private async void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var aid = this.pageParameters.GradeItem.AssignmentId;
            var type = this.TypeComboBox.SelectionBoxItem.ToString();
            var courseId = this.pageParameters.CourseId;

            var errors = this.validator.ValidateGradeItemEntries(this.NameTextBox.Text, this.DescriptionTextBox.Text, this.MaxGradeTextBox.Text,
                type, courseId);
            if (errors.Equals(""))
            {
                var name = this.NameTextBox.Text;
                var description = this.DescriptionTextBox.Text;
                var max = Int32.Parse(this.MaxGradeTextBox.Text);
                var gItem = new GradeItem(aid, courseId, name, description, type, max);
                this.controller.EditGradeItemInLocalDb(gItem);
                Frame.Navigate(typeof(GradeItemPage), this.pageParameters);
            }
            else
            {
                var entryErrorDialog = new ContentDialog
                {
                    Title = "Entry Error",
                    Content = "Unable to add item due to following errors: " + Environment.NewLine + errors,
                    PrimaryButtonText = "Okay"
                };
                var unused = await entryErrorDialog.ShowAsync();
            }
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            this.courseID = this.pageParameters.CourseId;
            var rItems = this.controller.GetAllRubricItems(this.courseID);
            this.types = this.controller.GetTypes(rItems);
            this.TypeComboBox.ItemsSource = this.types;
            this.TypeComboBox.SelectedItem = this.pageParameters.GradeItem.Type;

            this.IDLabel.Text += this.pageParameters.GradeItem.AssignmentId;
            this.NameTextBox.Text = this.pageParameters.GradeItem.Name;
            this.DescriptionTextBox.Text = this.pageParameters.GradeItem.Description;
            this.MaxGradeTextBox.Text = this.pageParameters.GradeItem.MaxGrade.ToString();
            this.usernameTextBox.Text = this.pageParameters.Username;
        }
    }
}
