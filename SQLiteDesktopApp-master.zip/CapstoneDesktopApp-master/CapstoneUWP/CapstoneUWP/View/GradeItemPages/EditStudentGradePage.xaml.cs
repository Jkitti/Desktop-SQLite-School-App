﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Repo_Model;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View.GradeItemPages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class EditStudentGradePage : Page
    {
        private ViewParameters pageParameters;
        private GradeItemController controller;
        private GradeItemGrade grade;

        public EditStudentGradePage()
        {
            this.InitializeComponent();
            this.controller = new GradeItemController();
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            this.grade = this.pageParameters.Grades.Peek();
            var repo = new GradeItemRepository();
            var displayitem = repo.CreateStudentGradeItemGrade(this.grade, this.pageParameters.CourseId);
            this.MaxLabel.Text += repo.GetGradeItem(this.grade.assignmentID).MaxGrade;
            this.IDLabel.Text += displayitem.Student;
            this.GradeItemLabel.Text += displayitem.itemName;
            
        }

        /// <summary>
        /// Handles the Click event of the HomePageButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void HomePageButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(CourseHomePage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Click event of the SubmitButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            var button = this.GradeTextBox;
            if (int.TryParse(button.Text, out _))
            {
                var newgrade = Int32.Parse(button.Text);
                if (InputValidator.ValidateGradeItemGrade(this.grade.assignmentID, newgrade))
                {
                    this.controller.UpdateGradeItemGrade(this.grade.assignmentID, this.grade.studentID, newgrade);
                    this.pageParameters.Grades.Dequeue();
                    if (this.pageParameters.Grades.Count != 0)
                    {
                        Frame.Navigate(typeof(EditStudentGradePage), this.pageParameters);
                    }
                    else
                    {
                        Frame.Navigate(typeof(CourseHomePage), this.pageParameters);
                    }
                }
                else
                {
                    var invalidGradeDialog = new ContentDialog
                    {
                        Title = "Grade Entry Error",
                        Content = "Grade must be between zero and the max grade",
                        PrimaryButtonText = "Okay"
                    };
                    var unused = await invalidGradeDialog.ShowAsync();
                }
            }
        }
    }
}
