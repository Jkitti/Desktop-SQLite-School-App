﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Repo_Model;
using CapstoneUWP.View.RubricPages;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GradeItemPage : Page
    {
        private ViewParameters pageParameters;
        private GradeItemController controller;

        public GradeItemPage()
        {
            this.InitializeComponent();
            this.controller = new GradeItemController();
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            var courseId = this.pageParameters.CourseId;
            var items = this.controller.GetAllGradeItemsByCourse(courseId);
            this.gradeItemList.ItemsSource = items;
            this.usernameTextBox.Text = this.pageParameters.Username;
            this.NavView.IsBackEnabled = true;
            this.NavView.Content = this.pageParameters.CourseName;
            this.NavView.IsBackEnabled = true;
            this.NavView.Content = this.pageParameters.CourseName;
        }

        /// <summary>
        /// Handles the Click event of the editButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var gradeItem = (GradeItem)button.DataContext;
            this.pageParameters.GradeItem = gradeItem;
            Frame.Navigate(typeof(EditGradeItemPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Click event of the deleteButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var gradeItem = (GradeItem)button.DataContext;
            this.controller.DeleteGradeItemFromLocalDb(gradeItem);
            Frame.Navigate(typeof(GradeItemPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Click event of the AddButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(AddGradeItemPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the RubricNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void RubricNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(RubricItemsPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the GradeItemNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void GradeItemNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(GradeItemPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the GradesNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void GradesNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(CourseGradesPage), this.pageParameters);
        }

        /// <summary>
        /// Navs the view back requested.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The <see cref="NavigationViewBackRequestedEventArgs"/> instance containing the event data.</param>
        private void NavView_BackRequested(NavigationView sender, NavigationViewBackRequestedEventArgs args)
        {
            Frame.Navigate(typeof(CourseHomePage), this.pageParameters);
        }
    }
}
