﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Display_Model;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class StudentGradesPage : Page
    {

        private ViewParameters pageParameters;
        private GradeItemController controller;

        public StudentGradesPage()
        {
            this.InitializeComponent();
            this.controller = new GradeItemController();
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            var gradeitem = this.pageParameters.GradeItem;
            var items = this.controller.GetAllGradedItemGradesById(gradeitem.AssignmentId);
            var studentGrades = new List<StudentGradeItemGrade>();
            foreach (var item in items)
            {
                var grade = this.controller.CreateStudentGradeItemGrade(item, this.pageParameters.CourseId);
                studentGrades.Add(grade);
            }
            this.studentGradeItemList.ItemsSource = studentGrades;
            this.usernameTextBox.Text = this.pageParameters.Username;
        }

        /// <summary>
        /// Handles the Click event of the HomePageButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void HomePageButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(CourseHomePage), this.pageParameters);
        }

        private async void gradeTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var button = (TextBox)sender;
            var gradeItem = (StudentGradeItemGrade)button.DataContext;
            if (int.TryParse(button.Text, out _))
            {
                var grade = Int32.Parse(button.Text);
                if (InputValidator.ValidateGradeItemGrade(gradeItem.assignmentID, grade))
                {
                    this.controller.UpdateGradeItemGrade(gradeItem.assignmentID, gradeItem.studentID, grade);
                    Frame.Navigate(typeof(StudentGradesPage), this.pageParameters);
                }
                else
                {
                    var invalidGradeDialog = new ContentDialog {
                        Title = "Grade Entry Error",
                        Content = "Grade must be between zero and the max grade",
                        PrimaryButtonText = "Okay"
                    };
                    var unused = await invalidGradeDialog.ShowAsync();
                }
            }
            else
            {
                var invalidInputDialog = new ContentDialog
                {
                    Title = "Grade Entry Error",
                    Content = "Grade must be only numbers",
                    PrimaryButtonText = "Okay"
                };
                var unused = await invalidInputDialog.ShowAsync();
            }
        }
    }
}
