﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using DataAccessLibrary;
using MySql.Data.MySqlClient;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class LoginPage : Page
    {
        private TeacherController controller = new TeacherController();
        private  ViewParameters parameters = new ViewParameters();
        public LoginPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Handles the Click event of the loginButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private async void loginButton_Click(object sender, RoutedEventArgs e)
        {
                await this.PushChanges();
                if (!this.controller.CheckForLocalData())
                {
                    DataAccess.InitializeDatabase();
                    this.controller.WriteCredentials(Int32.Parse(this.teacherIdTextBox.Text),
                        this.passwordTextBox.Password);
                    ChangelogModifier.CreateChangeLog();
                }

                if (this.controller.ValidateCredentials(Int32.Parse(this.teacherIdTextBox.Text), this.passwordTextBox.Password))
                {
                    this.parameters.Username = this.controller.GetUserName(Int32.Parse(this.teacherIdTextBox.Text));
                    Frame.Navigate(typeof(TeacherHomepage), this.parameters);
                }
            this.OfflineLogin();
        }

        private async void OfflineLogin()
        {
            try
            {
                if (this.controller.ValidateCredentials(Int32.Parse(this.teacherIdTextBox.Text),
                    this.passwordTextBox.Password))
                {
                    this.parameters.Username = this.controller.GetUserName(Int32.Parse(this.teacherIdTextBox.Text));
                    Frame.Navigate(typeof(TeacherHomepage), this.parameters);
                }

                else
                {
                    var invalidCredentialDialog = new ContentDialog
                    {
                        Title = "Login Error",
                        Content = "Credentials are invalid please try again",
                        PrimaryButtonText = "Okay"
                    };
                    var unused = await invalidCredentialDialog.ShowAsync();
                }
            }
            catch (Exception)
            {
                var invalidDbDialog = new ContentDialog
                {
                    Title = "Connection error",
                    Content = "No offline Db available, please connect to the server to create the offline db.",
                    PrimaryButtonText = "Okay"
                };
                var unused = await invalidDbDialog.ShowAsync();

            }
        }


        private async Task PushChanges()
        {
            try
            {
                await ChangelogModifier.OutputChanges();
            }
            catch (Exception)
            {
                return;
            }
        }
    }
}
