﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;
using CapstoneUWP.Model.Display_Model;
using CapstoneUWP.View.RubricPages;
using Microsoft.Toolkit.Uwp.UI.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CourseGradesPage : Page
    {
        private ViewParameters pageParameters;
        private CourseController controller;
        public ObservableCollection<StudentGradeItemGrade> Grades;

        public CourseGradesPage()
        {
            this.InitializeComponent();
            this.controller = new CourseController();
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            var courseId = this.pageParameters.CourseId;
            var items = this.controller.GetStudentGradesbyCourseId(courseId);
            var gradeItems = this.controller.GetStudentGradeItemGrades(courseId);
            this.Grades = new ObservableCollection<StudentGradeItemGrade>(gradeItems);
            this.DataGrid.ItemsSource = this.Grades;
            Debug.WriteLine(this.Grades.Count);
            this.usernameTextBox.Text = this.pageParameters.Username;
            this.studentGradeItemList.ItemsSource = items;
            this.NavView.IsBackEnabled = true;
            this.NavView.Content = this.pageParameters.CourseName;
        }

        /// <summary>
        /// Handles the Sorting event of the dg control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="DataGridColumnEventArgs"/> instance containing the event data.</param>
        private void dg_Sorting(object sender, DataGridColumnEventArgs e)
        {
            if (e.Column.SortDirection == null || e.Column.SortDirection == DataGridSortDirection.Ascending)
            {
                if (e.Column.Tag.ToString() == "Name")
                {
                    this.DataGrid.ItemsSource = new ObservableCollection<StudentGradeItemGrade>(from item in this.Grades
                                                                        orderby item.Student ascending
                                                                        select item);
                }

                if (e.Column.Tag.ToString() == "Item")
                {
                    this.DataGrid.ItemsSource = new ObservableCollection<StudentGradeItemGrade>(from item in this.Grades
                                                                                                orderby item.itemName ascending
                                                                                                select item);
                }
            }
        }

        /// <summary>
        /// Handles the Tapped event of the RubricNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void RubricNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(RubricItemsPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the GradeItemNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void GradeItemNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(GradeItemPage), this.pageParameters);
        }

        /// <summary>
        /// Handles the Tapped event of the GradesNav control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TappedRoutedEventArgs"/> instance containing the event data.</param>
        private void GradesNav_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(CourseGradesPage), this.pageParameters);
        }

        /// <summary>
        /// Navs the view back requested.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The <see cref="NavigationViewBackRequestedEventArgs"/> instance containing the event data.</param>
        private void NavView_BackRequested(NavigationView sender, NavigationViewBackRequestedEventArgs args)
        {
            Frame.Navigate(typeof(CourseHomePage), this.pageParameters);
        }
    }
}
