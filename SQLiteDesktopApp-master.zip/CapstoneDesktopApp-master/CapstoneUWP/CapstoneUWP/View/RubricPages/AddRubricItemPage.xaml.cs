﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using CapstoneUWP.Controller;
using CapstoneUWP.DAL.Repositories;
using CapstoneUWP.Model;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CapstoneUWP.View.RubricPages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AddRubricItemPage : Page
    {
        private ViewParameters pageParameters;
        private RubricController controller;
        private readonly InputValidator validator;

        public AddRubricItemPage()
        {
            this.InitializeComponent();
            this.validator = new InputValidator();
            this.controller = new RubricController();
        }

        /// <summary>
        /// Handles the Click event of the AddButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private async void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var percentageTotal = this.controller.RubricPercentageTotal(this.pageParameters.CourseId);
            var courseId = this.pageParameters.CourseId;
            var type = this.TypeTextBox.Text;

            var errors = this.validator.ValidateRubricType(type,this.pageParameters.CourseId);

            if (errors.Equals(""))
            {
                var grade = double.Parse(this.GradeTextBox.Text);
                var total = grade + percentageTotal;
                if (double.TryParse(this.GradeTextBox.Text, out _))
                {
                    if (total >= 1.0)
                    {
                        this.controller.AddRubricItem(courseId, type, grade);
                        Frame.Navigate(typeof(RubricItemsPage), this.pageParameters);
                    }
                    else
                    {
                        var invalidTotalDialog = new ContentDialog
                        {
                            Title = "Percentage Total Warning",
                            Content = "Combined rubric item percentage is below 1.0. Current total:" +
                                      percentageTotal,
                            PrimaryButtonText = "Okay"
                        };
                        var unused = await invalidTotalDialog.ShowAsync();

                        this.controller.AddRubricItem(courseId, type, grade);
                        Frame.Navigate(typeof(RubricItemsPage), this.pageParameters);
                    }
                }
                else
                {
                    var invalidTotalDialog = new ContentDialog {
                        Title = "Percentage Error",
                        Content = "Item percentage must be a decimal value",
                        PrimaryButtonText = "Okay"
                    };
                    var unused = await invalidTotalDialog.ShowAsync();
                }
            }
            else
            {
                var entryErrorDialog = new ContentDialog
                {
                    Title = "Entry Error",
                    Content = "Unable to add item due to following errors: " + Environment.NewLine + errors,
                    PrimaryButtonText = "Okay"
                };
                var unused = await entryErrorDialog.ShowAsync();
            }
        }

        /// <summary>
        /// Invoked when the Page is loaded and becomes the current source of a parent Frame.
        /// </summary>
        /// <param name="e">Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.pageParameters = (ViewParameters)e.Parameter;
            this.usernameTextBox.Text = this.pageParameters.Username;
        }

        /// <summary>
        /// Handles the Click event of the RubricPageButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs"/> instance containing the event data.</param>
        private void RubricPageButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(RubricItemsPage), this.pageParameters);
        }
    }
}
